These files are created by the uniqVec03 executable after Lynx dumping the web pages from the links on the following pages: 

IvanFranko -- http://poetyka.uazone.net/franko/

The version of the uniqueness-periods-vector-examples used for them is 0.4.0.0

The processment was done by Oleksandr Zhabenko, the author of the packages from uniqueness-periods-vector series. 


