These files are created by the uniqVec03 executable after Lynx dumping the web pages from the links on the following pages: 

LinaKostenko -- http://poetyka.uazone.net/kostenko/

The version of the uniqueness-periods-vector-examples used for them is 0.3.1.1

The processment was done by Oleksandr Zhabenko, the author of the packages from uniqueness-periods-vector series. 


